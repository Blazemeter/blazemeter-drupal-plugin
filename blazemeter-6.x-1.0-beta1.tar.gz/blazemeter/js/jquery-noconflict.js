var jQuery15 = jQuery;
jQuery.noConflict(true);